import java.util.Scanner;
import java.lang.Math;
public class polynomial {
	
	public static void main(String[] args){
		
	}
}
