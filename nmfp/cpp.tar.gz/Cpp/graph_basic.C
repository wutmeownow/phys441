#include <ostream>

Double_t fitfunction(Double_t *x, Double_t *par)
{
	Double_t f = par[0]+par[1]*x[0]+par[2]*pow(x[0],2.0);
	//Double_t f = par[0]*exp(par[1]*x[0]*x[0]);
	return f;
}

void graph_basic() {
   //
   //Modified: Edward J. Brash
   //		
  
   //gStyle->SetOptFit(kFALSE);	
   gStyle->SetOptFit(1);	
   TCanvas *c1 = new TCanvas("c1","Dependence on Interval Time",200,10,700,500);
   FILE *f = fopen("tinterval.txt","r");

   c1->SetFillColor(42);
   c1->SetGrid();
   c1->SetLogx();

   const Int_t n = 10000;
   Double_t tinterval[n], tbar[n], sigma[n], mean[n], rms[n], ey[n], ex[n], npoints[n];
   Int_t i=0;

   while (!feof(f)){
	  fscanf(f,"%lf %lf %lf %lf %lf %lf\n",&npoints[i],&tinterval[i],&tbar[i],&sigma[i],&mean[i],&rms[i]);
	  ex[i]=0.0;
	  ey[i]=sigma[i]/sqrt(npoints[i]);
	  i++;
   }

   const Int_t np=i;

   gr = new TGraphErrors(np,tinterval,tbar,ex,ey);
   TF1 *pfit1 = new TF1("fitfunction",fitfunction,0.0,1.0,3);
   pfit1->SetParameters(1.0,0.01,0.0001);
   pfit1->SetParNames("constant","linear","quadratic");
   //pfit1->SetParameters(12.0,-0.000000001);
   //pfit1->SetParNames("rho_0","linear");

//   gr->SetLineColor(2);
//   gr->SetLineWidth(4);
   gr->SetMarkerColor(kBlue);
   gr->SetMarkerStyle(21);
   gr->SetTitle("Interval Time Dependence");
   gr->GetXaxis()->SetTitle("t_interval");
   gr->GetYaxis()->SetTitle("t_bar");
//   TAxis *axis = gr->GetXaxis();
//   axis->SetLimits(-5.,5.);
//   gr->GetHistogram()->SetMaximum(40000.0);
//   gr->GetHistogram()->SetMinimum(0.0);
   gr->Fit("fitfunction","V");
   gr->Draw("AP");

   // TCanvas::Update() draws the frame, after which one can change it
   c1->Update();
   c1->GetFrame()->SetFillColor(21);
   c1->GetFrame()->SetBorderSize(12);
   c1->Modified();
}
