#include <iostream>

using namespace std;

int main(){

	cout << "Hello World! I can run a program using Visual C++ on Windows ... egads!!!";
	cout << std::endl;
	return 0;
}
