void graph_wavepacket_random() {
   //Draw a simple graph
   // To see the output of this macro, click begin_html <a href="gif/graph.gif">here</a>. end_html
   //Author: Rene Brun
   
   TCanvas *c1 = new TCanvas("c1","A Simple Graph Example",200,10,700,500);

   c1->SetFillColor(42);
   c1->SetGrid();

   const Int_t n = 8000;
   double pi=3.14159265;
   double lambda=1.0;
   double xlow = -32.0*lambda;
   double dx = 64.0*lambda/n;
   double k=2.0*pi/lambda;
   double delta_k=0.05*k;

   TRandom3 *rnum = new TRandom3();

   Double_t x[n], y[n], yf[n];
   for (Int_t i=0;i<n;i++) {
     x[i] = xlow+i*dx+0.00001;
/*   Add several waves together of equal amplitude ... */
     Double_t ysum=0.0;
     for (Int_t j=0; j<1000; j++){
	     //Double_t knew = k+rnum->Uniform(-delta_k,delta_k);
	     Double_t knew = k+rnum->Gaus(0.0,delta_k/2.0);
	     ysum=ysum+sin(knew*x[i]);
     }
     y[i]=ysum*ysum;

//     double y1 = sin(k*x[i]);
//     double y2 = sin((k-delta_k)*x[i]);
//     double y3 = sin((k+delta_k)*x[i]);
//     double y4 = sin((k-0.5*delta_k)*x[i]);
//     double y5 = sin((k+0.5*delta_k)*x[i]);
//     double y6 = sin((k-0.25*delta_k)*x[i]);
//     double y7 = sin((k+0.25*delta_k)*x[i]);
//     double y8 = sin((k-0.75*delta_k)*x[i]);
//     double y9 = sin((k+0.75*delta_k)*x[i]);
//     double ytemp  = y1+y2+y3+y4+y5+y6+y7+y8+y9;
//     y[i] = ytemp*ytemp;

/*   Fourier transform with equal amplitude from k-delta_k to k_delta_k */

     yf[i] = pow(sqrt(2.0/delta_k)*cos(k*x[i])*sin(delta_k*x[i])/x[i],2);

     printf(" i %i %f %f \n",i,x[i],y[i]);
   }
   gr = new TGraph(n,x,y);
   //gr->SetLineColor(2);
   //gr->SetLineWidth(4);
   gr->SetMarkerColor(2);
   //gr->SetMarkerStyle(21);
   gr->SetTitle("a simple graph");
   gr->GetXaxis()->SetTitle("X title");
   gr->GetYaxis()->SetTitle("Y title");
   gr2 = new TGraph(n,x,yf);
   //gr2->SetLineColor(3);
   //gr2->SetLineWidth(4);
   gr2->SetMarkerColor(3);
   //gr2->SetMarkerStyle(21);
   gr2->SetTitle("a simple graph");
   gr2->GetXaxis()->SetTitle("X title");
   gr2->GetYaxis()->SetTitle("Y title");
   //gr2->Draw("ACP");
   gr->Draw("ACP");

   // TCanvas::Update() draws the frame, after which one can change it
   c1->Update();
   c1->GetFrame()->SetFillColor(21);
   c1->GetFrame()->SetBorderSize(12);
   c1->Modified();
}
