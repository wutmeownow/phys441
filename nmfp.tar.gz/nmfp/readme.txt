All programs are copyrighted, 1999, by Alejandro Garcia.  The
routines supplement the book, "Numerical Methods for Physics",
2nd Ed. (Prentice Hall).

Original MATLAB Routines - Tested using MATLAB version 5.2.

Revised MATLAB Routines - Tested using MATLAB version 7.0.1.

C++ Routines - Tested using Microsoft Visual C++ version 5.0.

FORTRAN Routines - Tested using Digital Fortran 77 version 4.0.

These programs are provided for their instructional value.
Although every effort has been made to ensure that they are error
free, neither the author nor the publisher shall be held
responsible or liable for any damage resulting in connection with
or arising from the use of any of these programs.

********************************************
These programs are User Contributed Routines which
are being redistributed by The MathWorks, upon request, on an "as
is" basis. A User Contributed Routine is not a product of The
MathWorks, Inc. and The MathWorks assumes no responsibility for
any errors that may exist in these routines.
********************************************

If you have any questions or comments, please contact:

Alejandro Garcia
Dept. Physics
San Jose State University
San Jose CA 95192
algarcia@algarcia.org
