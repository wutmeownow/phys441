// General header file for C++ programs 
// in "Numerical Methods for Physics" 

#include <iostream.h>
#include <fstream.h>
#include <assert.h>  
#include <math.h>
#include "Matrix.h"
